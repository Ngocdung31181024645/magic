module.exports = {value:'foo'};
