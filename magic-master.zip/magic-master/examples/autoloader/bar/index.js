module.exports={value: 'bar'};
